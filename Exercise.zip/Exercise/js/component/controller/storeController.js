var app = angular.module("storeApp", [])
    .controller("storeController", function ($scope,$http,$timeout) {
		//Data populated from JSON
		$http.get("../../../product.json").success(function(data){
		$scope.data=data;
		//Filter of results, on basis of size
		$timeout(function(){
			for(item in data){
				for( var size=0;size < data[item].size.length; size++) {
					$('.product-list').eq(item).addClass(data[item].size[size]);
				}
			}
		},0);
			$scope.filterChange=function(sizeFilter){
				if(sizeFilter==="All" || sizeFilter===""){
					$('.product-list').show();
					return;
				}
				$('.product-list').hide();
				$('.product-list.'+sizeFilter).show();
			}
		}); 
});