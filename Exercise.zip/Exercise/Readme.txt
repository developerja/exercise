Below are some of the insights about the code written:
1. Angular 1 is used and angular 1.4.4 is the version being used
2. Jquery library jquery-2.1.4.min.js has been used
3. No bootstap framewrok being used
4. html is defined in index.html
5. css is written is styles.css
6. Folder structure created is: index.html at root level, then are the css and js folders, images folder
7.css folders contains the styles.css created
8. js folder contains libs and components folder, where libs folder contains the angular and jquery library files and components further contains controller folder which contains the storeController.js as the controller created
9.product.json is used to fetch the information in the json.It is populated in html using angular js.
10. Wave Accessibility Evaluation Tool has been used for accessibility check and no errors found
11. To run the application, i am committing the folder on Github and it can be run on locahost using apache etc.